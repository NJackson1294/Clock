#include <string>
#include <iostream>

using namespace std;

string formatTime12(unsigned int, unsigned int, unsigned int);
string formatTime24(unsigned int, unsigned int, unsigned int);
string nCharString(size_t, char);
string twoDigitString(unsigned int);

unsigned int getMenuChoice(unsigned int);

void addOneHour();
void addOneMinute();
void addOneSecond();
void displayClocks(unsigned int, unsigned int, unsigned int);
void printMenu(unsigned char);
void mainMenu();
