#include "Clock.h"


int main() {
	displayClocks(0, 0, 0);
	mainMenu();
	return 0;
}