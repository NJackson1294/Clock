#include "Clock.h"
#include <string>
#include <iostream>
using namespace std;

unsigned int hours = 0;
unsigned int minutes = 0;
unsigned int seconds = 0;

void setHour(int h) {

    hours = h;

}

int getHour() {

    return hours;

}

void setMinute(int m) {

   minutes = m;

}

int getMinute() {

    return minutes;

}

void setSecond(int s) {

    seconds = s;

}

int getSecond() {

    return seconds;

}



void addOneHour() {

    if (getHour() >= 0 && getHour() < 23) {
        setHour(getHour() + 1); // Increment hour if within range
    }
    if (getHour() == 23) {
        setHour(0); // Reset hour to 0
    }
}

void addOneMinute() {

    if (getMinute() >= 0 && getMinute() < 60) {
        setMinute(getMinute() + 1); // Increment minute if within range
    }
    if (getMinute() == 60) {
        setMinute(0); // Reset minute to 0
        addOneHour(); // Increment hour if minute wraps around
    }
}

void addOneSecond() {

    if (getSecond() >= 0 && getSecond() < 60) {
        setSecond(getSecond() + 1); // Increment second if within range
    }
    if (getSecond() == 60) {
        setSecond(0); // Reset second to 0
        addOneMinute(); // Increment minute if second wraps around
    }
}

void displayClocks(unsigned int h, unsigned int m, unsigned int s) {
    string border(27, '*');

    cout << border << "   " << border << "\n";
    cout << "*      " << "12-HOUR CLOCK" << "      *   ";
    cout << "*      " << "24-HOUR CLOCK" << "      *\n";
    cout << "\n";
    cout << "*      " << formatTime12(h, m, s) << "       *   ";
    cout << "*        " << formatTime24(h, m, s) << "         *\n";
    cout << border << "   " << border << "\n";
}

string formatTime12(unsigned int h, unsigned int m, unsigned int s) {

    string suffix = (h >= 12) ? "P M" : "A M"; // Determine AM or PM suffix
    h = (h % 12 == 0) ? 12 : h % 12; // Convert 24-hour format to 12-hour format

    string hr = twoDigitString(h);
    string min = twoDigitString(m);
    string sec = twoDigitString(s);

    string str = hr + ":" + min + ":" + sec + " " + suffix;

    return str; // replace this placeholder with return of your formatted string
}

string formatTime24(unsigned int h, unsigned int m, unsigned int s) {

    // return time as hh:mm:ss
    string str = "";
    str += twoDigitString(h) + ":" + twoDigitString(m) + ":" + twoDigitString(s);
    return str;
}

unsigned int getMenuChoice(unsigned int maxChoice) {

    unsigned int choice;
    bool isValidChoice = false;
    while (!isValidChoice) {
        cin >> choice;

        if (choice >= 1 && choice <= maxChoice) {
            isValidChoice = true; // Set isValidChoice to true if choice is within range
        }
        else {
            isValidChoice = false; // Set isValidChoice to false if choice is outside range
        }
    }

    return choice; // Return the valid choice
}

string nCharString(size_t n, char c) {

    // return the n character string
    string str = "";
    for (size_t i = 0; i < n; ++i) {
        str += c;
    }
    return str;
}

void printMenu(unsigned char width) {
    const char* strings[] = {
        "Add One Hour",
        "Add One Minute",
        "Add One Second",
        "Exit Program"
    };
    unsigned int numStrings = sizeof(strings) / sizeof(strings[0]);

    cout << nCharString(width, '*') << endl;
    for (unsigned int i = 0; i < numStrings; ++i) {
        cout << "* " << i + 1 << " - " << strings[i] << nCharString(width - strlen(strings[i]) - 7, ' ') << '*' << endl;
        if (i < numStrings - 1) {
            cout << endl;
        }
    }
    cout << nCharString(width, '*') << endl;
    // outside the loop print another width *s followed by an endl
}

string twoDigitString(unsigned int n) {
    string out = "";
    if (n >= 0 && n < 10) {
        out = "0";
        out += to_string(n);
    }
    else {
        out = to_string(n);
    }
    return out;
}

void mainMenu() {
    unsigned int choice;
    unsigned int Choices1 = 4; // Initialize Choices1 to 4

    do {
        printMenu(30);
        choice = getMenuChoice(Choices1);

        switch (choice) {
            case 1:
                addOneHour();
                break;
            case 2:
                addOneMinute();
                break;
            case 3:
                addOneSecond();
                break;
            case 4:
                break;
            default:
                break;

        }
        displayClocks(hours, minutes, seconds);
    } while (choice != 4);
}

